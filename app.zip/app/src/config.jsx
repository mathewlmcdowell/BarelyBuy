export const SITE_NAME = 'Online Shopping';
export const API_URL = 'http://localhost:8081';
export const SERVER_ROOT = 'http://localhost:8081';
